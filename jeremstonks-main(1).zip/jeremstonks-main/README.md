# jeremstonks

I leverage a forecasting package in R to predict future growth paths of stocks. I'm jerem, they are stonks. Jeremstonks
